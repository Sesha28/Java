package com.alstom.SpringMVC;


import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;



@Controller
public class MainController {

	@Autowired
	private HttpServletRequest request;

	@Autowired
	private HttpServletResponse response;
	
	@RequestMapping("/")
	public String Index(@RequestParam(name="name", required=false, defaultValue="SpringBoot App") String name, Model model) {
		model.addAttribute("name", name); //Home.html
		model.addAttribute("page", "Home"); 
		model.addAttribute("subheading", "More like Flask/NodeJS");
		return "/Shared/Layout";		
	}
	
	@RequestMapping("/Home")
	public String greeting(@RequestParam(name="name", required=false, defaultValue="SpringBoot App") String name, Model model) {
		model.addAttribute("name", name);
		model.addAttribute("page", "Home");
		model.addAttribute("subheading", "Welcome to home");
		return "/Shared/Layout" ;//"Home";
	}
	@RequestMapping("/About")
	public String AboutUS(@RequestParam(name="name", required=false, defaultValue="World") String name, Model model) {
		model.addAttribute("page", "About");
		model.addAttribute("name", name);
		List<Employee> lsd =  new ArrayList<Employee>();
		for(int i=0;i<10; ++i) {
			Employee emp =  new Employee(i, "Sanjana_" + i);
			lsd.add(emp);
		}
		
		model.addAttribute("Employees", lsd);
		return "/Shared/Layout" ;//"About";
	}
	@RequestMapping("/Tables")
	public String ShowTables(@RequestParam(name="name", required=false, defaultValue="World") String name, Model model) {
		model.addAttribute("page", "Tables");
		model.addAttribute("name", name);
		return "/Shared/Layout" ;//"Tables";
	}
	@RequestMapping("/welcome")
	public @ResponseBody String welcome() {
		request.getSession().setAttribute("Labamba", "Rahul");
		String z = request.getParameter("Zola");
		if (z == null)
			z = " Oh Z is NULL";

		if (z.length() <= 0)
			z = "absolutly nothing";
		return "Welcome to Spring Boot in Life, Good life \n" + z;
	}
	@RequestMapping(method = RequestMethod.GET, value = "/GetEmployee")
	public @ResponseBody Employee GetEmp() {
		Employee emp = new Employee();
		return emp;
	}

	
}