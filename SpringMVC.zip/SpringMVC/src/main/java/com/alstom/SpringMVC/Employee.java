package com.alstom.SpringMVC;


public class Employee {
	int Age;
	String Name;
	public int getAge() {
		return Age;
	}
	public void setAge(int age) {		
		Age = age;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public Employee(int age, String name) {
		super();
		Age = age;
		Name = name;
	}
	public Employee() {
		super();
		Age = 21;
		Name = "Labamba";
	}
}