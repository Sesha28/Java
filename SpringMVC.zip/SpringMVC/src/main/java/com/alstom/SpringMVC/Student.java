package com.alstom.SpringMVC;


public class Student{
	public int Age;
	public String Name;
	public String Address;
	public Student(String Name, int Age , String Address) {
		this.Age = Age;
		this.Name = Name;
		this.Address = Address;		
	}
}