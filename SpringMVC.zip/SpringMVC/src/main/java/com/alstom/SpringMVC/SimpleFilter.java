package com.alstom.SpringMVC;

import java.io.IOException;

import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Component;

/**
 * Servlet Filter implementation class SimpleFilter
 */
@Component
@WebFilter(description = "A filter for login", urlPatterns = { "/*" })
public class SimpleFilter implements Filter {

	static String LogInPageRequestMapping = "/Login";
	static String LogInAuthRequestMapping = "/doLogIn";
	static List<String> FreeRide = List.of(".css", ".js", ".jpg", ".png", ".svg", "/About");

	/**
	 * Default constructor.
	 */
	public SimpleFilter() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest) req;
		HttpServletResponse response = (HttpServletResponse) res;

		//request.getHeader("Authorizarion")
		if (SimpleFilter.FreeRide.stream().anyMatch(x -> request.getRequestURI().endsWith(x))) {
			chain.doFilter(req, res);
			return;
		}
//		if (request.getRequestURI().endsWith(".css") || request.getRequestURI().endsWith(".js") || request.getRequestURI().endsWith(".jpg")) {
//			chain.doFilter(req, res);
//			return;
//		}
		if (request.getRequestURI().endsWith(SimpleFilter.LogInPageRequestMapping)) {
			if (isAuthenticated(request, response)) {
				// go to home page
				response.sendRedirect("/");
				return;
			} else // u r n login page & u r !authenticated
			{
				// go ahead and do log in
				chain.doFilter(req, res);
				return; // nothing to do
			}

		} else // url is not the login page, i.e some other page
		{
			// no-authentication for this servlet, this is where the log in code resides.
			if (request.getRequestURI().endsWith(SimpleFilter.LogInAuthRequestMapping)) {
				// proceed further no auth required for this servlet
				chain.doFilter(req, res);
				return;
			} else // url is not the JambaServlet
			{
				if (!isAuthenticated(request, response)) {
					response.sendRedirect(SimpleFilter.LogInPageRequestMapping); // the actual code
					return;
				} else // url is authenticated
				{
					chain.doFilter(req, res); // proceed further
					return;
				}
			}
		}
//		chain.doFilter(req, res);
	}

	public static Boolean isAuthenticated(HttpServletRequest request, HttpServletResponse response) {
		if ("TRUE" == request.getSession().getAttribute("AUTHENTICATED"))
			return true;
		return false;
//		Cookie[] cookies = request.getCookies();
//		for (int i = 0; i < cookies.length; i++) {
//			Cookie cookie = cookies[i];
//			String cookieName = cookie.getName();
//			String cookieValue = cookie.getValue();
//			if(cookieName == "AUTHEN" && cookieValue == "YES"){
//				return true;
//			}
//		}
//		return false;
	}

	public static Cookie getAuthCookie(HttpServletRequest request, HttpServletResponse response) {
		Cookie[] cookies = request.getCookies();
		for (int i = 0; i < cookies.length; i++) {
			Cookie cookie = cookies[i];
			String cookieName = cookie.getName();
			String cookieValue = cookie.getValue();
			if (cookieName == "AUTHEN" && cookieValue == "YES") {
				return cookie;
			}
		}
		return null;
	}

	public static void LogOnUser(HttpServletRequest request, HttpServletResponse response, String userName) {
//		Cookie cook = new Cookie("AUTHEN", "YES");
//		response.addCookie(cook);
		request.getSession().invalidate();
		request.getSession().setAttribute("AUTHENTICATED", "TRUE");
		request.getSession().setAttribute("USERNAME", userName);
	}

	public static void LogOffUser(HttpServletRequest request, HttpServletResponse response, String userName) {
//		Cookie cook = getAuthCookie(request, response);
//		cook.setValue(null);
//		cook.setMaxAge(0);
//		response.addCookie(cook);
		request.getSession().invalidate();
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}