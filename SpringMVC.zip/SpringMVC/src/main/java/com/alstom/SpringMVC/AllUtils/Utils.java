package com.alstom.SpringMVC.AllUtils;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletResponse;

public class Utils {
	/*
	 * Convert ResultSet to a common JSON Object array Result is like:
	 * [{"ID":"1","NAME":"Tom","AGE":"24"}, {"ID":"2","NAME":"Bob","AGE":"26"}, ...]
	 */
	public static List<HashMap<String, Object>> getFormattedResultHashMap(ResultSet rs) {
		List<HashMap<String, Object>> resList = new ArrayList<HashMap<String, Object>>();
		try {
			// get column names
			ResultSetMetaData rsMeta = rs.getMetaData();
			int columnCnt = rsMeta.getColumnCount();
			List<String> columnNames = new ArrayList<String>();
			for (int i = 1; i <= columnCnt; i++) {
				columnNames.add(rsMeta.getColumnName(i).toUpperCase());
			}

			while (rs.next()) { // convert each object to an human readable JSON object
				HashMap<String, Object> obj = new HashMap<String, Object>();
				for (int i = 1; i <= columnCnt; i++) {
					String key = columnNames.get(i - 1);
					obj.put(key, rs.getObject(i));
				}
				resList.add(obj);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return resList;
	}

	public static List<HashMap<String, Object>> MakeErrorMsg(Exception e) {
		List<HashMap<String, Object>> lsd = new ArrayList<HashMap<String, Object>>();
		HashMap<String, Object> hm = new HashMap<String, Object>();
		hm.put("Error-Message", e.getMessage());
		hm.put("STack-Trace", e.getStackTrace());
		lsd.add(hm);
		return lsd;
	}

	public static boolean StringIsNullOrEmpty(String string) {
		return (string == null || string.isEmpty() || string.trim().isEmpty());
	}

	public static int TryParseStringToInt(String str, int defaultValue) {
		int id = defaultValue;
		try {
			id = Integer.parseInt(str);
		} catch (NumberFormatException nfe) {
			id = defaultValue;
		}
		return id;
	}
	public static void returnImage(HttpServletResponse response, String image_path) throws IOException {
		response.setContentType("image/jpeg");
		File imgFile = new File(image_path);
//		File randFile = new File("C:\\WOI\\Pict\\14.jpg");
		BufferedImage bi = ImageIO.read(imgFile);
		OutputStream out = response.getOutputStream();
		ImageIO.write(bi, "jpg", out);
		out.close();
	}
}
