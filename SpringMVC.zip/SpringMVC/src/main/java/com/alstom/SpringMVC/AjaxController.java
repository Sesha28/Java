package com.alstom.SpringMVC;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Type;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.alstom.Business.BusinessLayer;
import com.alstom.SpringMVC.AllUtils.Utils;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import com.alstom.Models.*;

@RestController
public class AjaxController {

	static final String ImageFolder = "C:\\woi\\pict\\";

	static final String DB_URL = "jdbc:postgresql://localhost:5432/dvdrental";
	static final String USER = "postgres";
	static final String PASS = "root@123";

	@Autowired
	private HttpServletRequest request;

	@Autowired
	private HttpServletResponse response;

	@RequestMapping(method = RequestMethod.GET, value = "/GetEmployees")
	public List<Employee> GetEmps() {
		List<Employee> lsd = new ArrayList<>();
		for (int i = 0; i < 10; ++i) {
			Employee emp = new Employee(i, "Name_" + i);
			lsd.add(emp);
		}
		return lsd;
	}

	@RequestMapping(value = "/GetTables", method = RequestMethod.GET)
	public List<HashMap<String, Object>> GetTables() throws IOException, ClassNotFoundException {
		return BusinessLayer.GetTablesInDVDRental();
	}

	@RequestMapping(value = "/GetTable", method = RequestMethod.GET)
	public List<HashMap<String, Object>> GetTable() throws IOException, ClassNotFoundException {
		String table_name = (String) request.getParameter("table_name");
		if (Utils.StringIsNullOrEmpty(table_name))
			return null;
		return BusinessLayer.GetTable(table_name);
	}

	@RequestMapping(value = "/GetActor", method = RequestMethod.GET)
	public List<HashMap<String, Object>> GetActor() throws SQLException {
		int id = Utils.TryParseStringToInt(request.getParameter("id"), 0);
		return BusinessLayer.GetActor(id);
	}

	@RequestMapping(value = "/Student", method = RequestMethod.GET)
	public @ResponseBody String GetStudent() {
		// https://futurestud.io/tutorials/gson-mapping-of-arrays-and-lists-of-objects
		Gson gson = new Gson();

//		String str = "[{\"Age\":0,\"Name\":\"Name_0_Labamba\"}, {\"Age\":6,\"Name\":\"Name_6_Labamba\"}]";
//		Student[] sss = gson.fromJson(str, Student[].class);
//		List<Student> sss = gson.fromJson(str, Student[].class);

//		Type t= new TypeToken<Student[]>(){}.getType();
//		Student[] sss = gson.fromJson(str, t);

//		str = gson.toJson(sss);
		List<Student> lsd = new ArrayList<Student>();
		for (int i = 0; i < 10; ++i) {
			lsd.add(new Student("Name_" + i, i, "Bangalore_" + i));
		}
		String str = gson.toJson(lsd);

		Type t = new TypeToken<List<Student>>() {
		}.getType();
		List<Student> Students = gson.fromJson(str, t);
		for (Student s : Students)
			s.Name += "_Labamba";
		str = gson.toJson(Students);

		return str;
	}

	@RequestMapping(value = "/ScCall", method = RequestMethod.GET)
	public @ResponseBody String SecondCallforEquipments(String EquipmentModel_Caption) throws IOException {
		// List<LRU>
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		String str = FileUtils.readFileToString(new File("C:\\WOI\\Data\\ATS.json"), "utf-8");
		LRU[] lrus = gson.fromJson(str, LRU[].class);
		int index = 0;
		for (LRU l : lrus)
			l.Gol = "Goli_" + ++index;
		lrus[0].Color = "red";
		str = gson.toJson(lrus);
//		System.out.println(str);
		return str;
	}

	// GET : URL : ~/image?FileName=a.jpg
	@RequestMapping(value = "/image", method = RequestMethod.GET, produces = MediaType.IMAGE_JPEG_VALUE)
	public @ResponseBody byte[] getImageWithMediaType() throws IOException {
		String FileName = request.getParameter("FileName");
		if (FileName == null || FileName.isBlank())
			FileName = "Ram.jpg";
		var img = new File(AjaxController.ImageFolder + FileName);
		InputStream in = new ByteArrayInputStream(FileUtils.readFileToByteArray(img));
		return IOUtils.toByteArray(in);
	}

	@RequestMapping(value = "/getfile", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public @ResponseBody byte[] getFile() throws IOException {
		response.addHeader("Content-Disposition", "attachment; filename=image.gif");
		var img = new File("C:\\WOI\\pict\\image.gif");
		return FileUtils.readFileToByteArray(img);
	}
}
