package com.alstom.SpringMVC;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
//import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.alstom.SpringMVC.AllUtils.Utils;

@RestController
public class AjaxController {

	static final String DB_URL = "jdbc:postgresql://localhost:5432/dvdrental";
	static final String USER = "postgres";
	static final String PASS = "root@123";

	@Autowired
	private HttpServletRequest request;

//	@Autowired
//	private HttpServletResponse response;

	@RequestMapping(method = RequestMethod.GET, value = "/GetEmployees")
	public List<Employee> GetEmps() {
		List<Employee> lsd = new ArrayList<>();
		for (int i = 0; i < 10; ++i) {
			Employee emp = new Employee(i, "Name_" + i);
			lsd.add(emp);
		}
		return lsd;
	}

	@RequestMapping(value = "/GetTables", method = RequestMethod.GET)
	public List<HashMap<String, Object>> GetTables() throws IOException, ClassNotFoundException {
		String QUERY = "SELECT table_name FROM information_schema.tables where table_schema = 'public'";
		// Class.forName("org.postgresql.Driver");
		try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
				Statement stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(QUERY);) {
			return Utils.getFormattedResultHashMap(rs);
		} catch (SQLException e) {
			return Utils.MakeErrorMsg(e);
		}
	}

	@RequestMapping(value = "/GetTable", method = RequestMethod.GET)
	public List<HashMap<String, Object>> GetTable() throws IOException, ClassNotFoundException {
		String table_name = (String) request.getParameter("table_name");
		String QUERY = "SELECT * from " + table_name;
		
		// Class.forName("org.postgresql.Driver");
		try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
				Statement stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(QUERY);) 
		{
//			PreparedStatement stmt = conn.prepareStatement("SELECT * from ?");
//			stmt.setString(1, table_name);
//			System.out.println(stmt.toString());
//			ResultSet rs = stmt.executeQuery();
			conn.close();
			return Utils.getFormattedResultHashMap(rs);
		} catch (SQLException e) {
			return Utils.MakeErrorMsg(e);
		}
	}
}
