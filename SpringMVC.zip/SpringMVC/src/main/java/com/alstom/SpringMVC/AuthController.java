package com.alstom.SpringMVC;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.alstom.Business.*;
import com.alstom.SpringMVC.AllUtils.Utils;
//import org.springframework.web.bind.annotation.ResponseBody;
import com.alstom.utils.SessionValues;
import com.google.gson.Gson;

@Controller
public class AuthController {

	@Autowired
	private Environment env;

//	@Autowired
//	private HttpServletRequest request;

//	@Autowired
//	private HttpServletResponse response;

	@RequestMapping("/Login")
	public String Index(@RequestParam(name = "name", required = false, defaultValue = "SpringBoot App") String name,
			Model model) {
		model.addAttribute("name", name);
		model.addAttribute("page", "login");
		return "/Shared/Layout";
	}

	@RequestMapping(value = "/doLogIn", method = RequestMethod.POST)
	public void doLogIn(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String uName = request.getParameter("username");
		String pwd = request.getParameter("password");

		if (BusinessLayer.CanUserLogOn(uName, pwd))
			SimpleFilter.LogOnUser(request, response, uName);
		response.sendRedirect("/");
	}

	@RequestMapping(value = "/SignOut", method = RequestMethod.GET)
	public void SignOut(HttpServletRequest request, HttpServletResponse response) throws IOException {
		SimpleFilter.LogOffUser(request, response, null);
		request.getSession().invalidate();
		response.sendRedirect("/");
	}

	@RequestMapping(value = "/GetUserInfo", method = RequestMethod.GET)
	public @ResponseBody String GetUserInfo(HttpServletRequest request, HttpServletResponse response) {
		UserInfo usa = new UserInfo((int) 12, SessionValues.getUSERNAME(request), SessionValues.getRoles(request));
		Gson g = new Gson();
		return g.toJson(usa);
	}

	@RequestMapping(value = "/GetProfileImage", method = RequestMethod.GET)
	public @ResponseBody void GetProfileImage(HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		String ProfileImagePath = env.getProperty("profile.path") + SessionValues.getUSERNAME(request) + "\\"
				+ SessionValues.getUSERNAME(request);
		//Utils.returnImage(response, ProfileImagePath);
		File  f =  new File(ProfileImagePath);
		if(f.isFile()) Utils.returnImage(response, ProfileImagePath);
		else {
			String default_img = env.getProperty("default_image.path") + "0.jpg";
			Utils.returnImage(response, default_img);		
		}		
	}

	@PostMapping("/SubmitProfileImage") // //new annotation since 4.3
	public @ResponseBody String SubmitProfileImage(HttpServletRequest request, HttpServletResponse response,
			@RequestParam("file") MultipartFile file, RedirectAttributes redirectAttributes) {
		if (file.isEmpty()) {
			redirectAttributes.addFlashAttribute("message", "Please select a file to upload");
			return "redirect:uploadStatus";
		}

		try {

			// Get the file and save it somewhere
			byte[] bytes = file.getBytes();
			String ProfilePath = env.getProperty("profile.path");// "C:\\WOI\\A\\Profile" + file.getOriginalFilename();
			new File(ProfilePath).mkdir();
			ProfilePath += SessionValues.getUSERNAME(request);
			System.out.println("Profile Path : " + ProfilePath);
			new File(ProfilePath).mkdir();
			String ThePath = ProfilePath + "\\" + SessionValues.getUSERNAME(request);
			System.out.println("Full Image Path : " + ThePath);
			Path path = Paths.get(ThePath);
			Files.write(path, bytes);
			redirectAttributes.addFlashAttribute("message",
					"You successfully uploaded '" + file.getOriginalFilename() + "'");
			// return "/Images/Profile/" + SessionValues.getUSERNAME(request) + "/" +
			// SessionValues.getUSERNAME(request);
			return "/GetProfileImage";

		} catch (IOException e) {
			e.printStackTrace();
		}

		return "File Upload Damar";
	}
}
