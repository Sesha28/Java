package com.alstom.SpringMVC;

import java.io.IOException;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

//import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class AuthController {

//	@Autowired
//	private HttpServletRequest request;

//	@Autowired
//	private HttpServletResponse response;

	@RequestMapping("/Login")
	public String Index(@RequestParam(name = "name", required = false, defaultValue = "SpringBoot App") String name,
			Model model) {
		model.addAttribute("name", name);
		model.addAttribute("page", "login");
		return "/Shared/Layout";
	}

	@RequestMapping(value = "/doLogIn", method = RequestMethod.POST)
	public void doLogIn(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String uName = request.getParameter("username");
		SimpleFilter.LogOnUser(request, response, uName);
		response.sendRedirect("/");
	}
	
	@RequestMapping(value = "/SignOut", method = RequestMethod.GET)
	public void SignOut(HttpServletRequest request, HttpServletResponse response) throws IOException {
		SimpleFilter.LogOffUser(request, response, null);
		request.getSession().invalidate();
		response.sendRedirect("/");
	}
}
