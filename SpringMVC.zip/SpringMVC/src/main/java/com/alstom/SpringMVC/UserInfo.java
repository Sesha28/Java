package com.alstom.SpringMVC;

public class UserInfo {

	int id;
	String name ;
	String[] roles ;
	
	public String[] getRoles() {
		return roles;
	}

	public void setRoles(String[] roles) {
		this.roles = roles;
	}

	public UserInfo(int id, String name , String[] roles) {
		super();
		this.id = id;
		this.name = name;
		this.roles = roles;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String userName) {
		name = userName;
	}

	
	
	
}
