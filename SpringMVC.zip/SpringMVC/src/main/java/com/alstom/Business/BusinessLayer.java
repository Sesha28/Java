package com.alstom.Business;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;

import com.alstom.DataAccess.DataAccessLayerPostgres;
import com.alstom.Queries.PGSqLQueries;
import com.alstom.SpringMVC.AllUtils.Utils;

public class BusinessLayer {

	public static boolean CanUserLogOn(String uname, String pwd) {

		// run to database to match the credentials.
		// if match is successful call SimpleFilter.LogOnUser(request, response, uName);
		// else response.sendRedirect("/");
		return true;
	}

	public static List<HashMap<String, Object>> GetTablesInDVDRental() {
		return DataAccessLayerPostgres.GetDataTable(PGSqLQueries.GetAllTables);
	}

	public static List<HashMap<String, Object>> GetTable(String table_name) {
		if (Utils.StringIsNullOrEmpty(table_name))
			return null;
		return DataAccessLayerPostgres.GetDataTable(PGSqLQueries.GetTable.replace("_TABLE_NAME_", table_name));
	}

	public static List<HashMap<String, Object>> GetActor(int actor_id) throws SQLException {
		try (Connection con = DataAccessLayerPostgres.GetConnection();
				PreparedStatement ps = con.prepareStatement(PGSqLQueries.GetActor);) {
			ps.setInt(1, actor_id);
			Dictionary<Integer, Object> ola = new Hashtable<Integer, Object>();
			ola.put(1, 21);
			ola.put(2, "Lamba");
			ola.put(3, 123.45);
			
			return DataAccessLayerPostgres.GetDataTable(con, ps);
		}
	}
}
