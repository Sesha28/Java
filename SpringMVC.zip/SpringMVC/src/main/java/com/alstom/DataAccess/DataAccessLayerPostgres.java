package com.alstom.DataAccess;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.List;

import com.alstom.SpringMVC.AllUtils.Utils;

public class DataAccessLayerPostgres {

	static final String DB_URL = "jdbc:postgresql://localhost:5432/dvdrental";
	static final String USER = "postgres";
	static final String PASS = "root@123";

	public static Connection GetConnection() throws SQLException {
		return DriverManager.getConnection(DataAccessLayerPostgres.DB_URL, DataAccessLayerPostgres.USER,
				DataAccessLayerPostgres.PASS);
	}
	public static int ExecuteScalar(String sql) 
    {
		try (Connection conn = DataAccessLayerPostgres.GetConnection();Statement statement =  conn.createStatement();){
			return statement.executeUpdate(sql);			
		}catch (SQLException e) {
			return -1;
		}
    }
	public static int ExecuteScalar(Connection con, PreparedStatement statement)
    {
		try (Connection conn = con;PreparedStatement stmt = statement; ) {
			return stmt.executeUpdate();
		} catch (SQLException e) {			
			return -1;
		}
    }
	public static List<HashMap<String, Object>> GetDataTable(String sqlQuery) {
		try (Connection conn = DataAccessLayerPostgres.GetConnection();
				Statement stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(sqlQuery);) {			
			return Utils.getFormattedResultHashMap(rs);
		} catch (SQLException e) {
			return Utils.MakeErrorMsg(e);
		}
	}

	public static List<HashMap<String, Object>> GetDataTable(Connection con, PreparedStatement statement) {
		try (Connection conn = con; PreparedStatement stmt = statement; ResultSet rs = stmt.executeQuery();) {
			return Utils.getFormattedResultHashMap(rs);			
		} catch (SQLException e) {			
			return Utils.MakeErrorMsg(e);
		}
	}
}
