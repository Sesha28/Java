package com.alstom.utils;


import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;

//import org.springframework.beans.factory.annotation.Autowired;

public class SessionValues {

//	@Autowired //Autowire will not work for static variables, ok, one way it is good also
//	private static HttpServletRequest request;
	
	public static String[] getRoles(HttpServletRequest request) {
		return (String[]) request.getSession().getAttribute("Roles");
	}

	public static void setRoles(HttpServletRequest request, String[] roles) {
		request.getSession().setAttribute("Roles", roles);
	}

	public static String getUSERNAME(HttpServletRequest request) {
		return (String) request.getSession().getAttribute("USERNAME");
	}

	public static void setUSERNAME(HttpServletRequest request, String user_name) {
		request.getSession().setAttribute("USERNAME", user_name);
	}
	

	public static Boolean getAUTHENTICATED(HttpServletRequest request) {
		Boolean b = (Boolean) request.getSession().getAttribute("AUTHENTICATED");
		if(b ==  null) return false;
		return b;
	}
	
	public static void setAUTHENTICATED(HttpServletRequest request, Boolean authenticated) {
		request.getSession().setAttribute("AUTHENTICATED", authenticated);
	}
}