package com.alstom.Models;

public class LRU {
	  public String Caption ;
      public String Color ; //green, red,orange,yellow,purple,blue,grey
      public int X1 ;
      public int Y1 ;
      public int X2 ;
      public int Y2 ;
      public Boolean EqtMode ;
      public String Gol;
}
