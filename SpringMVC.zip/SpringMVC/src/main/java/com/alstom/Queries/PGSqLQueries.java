package com.alstom.Queries;

public class PGSqLQueries {

	public static final String GetAllTables = "SELECT table_name FROM information_schema.tables where table_schema = 'public'";
	public static final String GetTable = "SELECT * from _TABLE_NAME_";
	public static final String GetActor = "SELECT * from actor where actor_id < ?";
}
