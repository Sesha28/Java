﻿var udc = {
	start_action: function (tag, data) {
        return new TemplateRenderer(data, tag, "~/Scripts/Components/UDC/udc.html", null, false).start_action().
            then(jData => {                
                return "From udc";
            });
    },
    upload: function(e) {
        alert("About to upload");
        let photo = document.getElementById("thefile").files[0];
        let formData = new FormData();
        formData.append("file", photo);
        $.ajax({
            url: config.contextPath + "upload",
            cache: false,
            data: formData,
            contentType: false,
            processData: false,
            method: 'POST',
            type: 'POST', // For jQuery < 1.9
            success: function(jData) {
                alert(jData);
            },
            error: function(a, b, c) {
                alert(JSON.stringify(a));
                alert(JSON.stringify(b));
                //alert(JSON.parse(a.responseText).message);
            }
        });
	 },
	 expt:function(e){
		alert("Labamba");
		$.ajax({url : config.contextPath + "DoExpt"}).
		done(jData => alert(jData)).
		fail((a,b) => {
			 alert(JSON.stringify(a));
             alert(JSON.stringify(b));
		});
	}
}
