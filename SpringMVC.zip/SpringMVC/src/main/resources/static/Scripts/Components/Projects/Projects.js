﻿var Nominations = {
    dt: null,
    myModal: null,
    ids: ['Name', 'Position', 'Office', 'Age', 'Start date', 'Salary'],
    headermapping: {
        SNo: "#",
        id: "ID",
        filed_by_user_id: "Filed by ID",
        candidate_name: "Name",
        reporting_manager_name: "Manager",
        current_position: "Current",
        proposed_position: "Proposed",
        dept_head_name: "Dept. Head",
        sponsor_mail: "Sponsor",
        filed_by_user_name: "Filed by",
        candidate_mail: "Mail",
        file_name: "File",
        extra_info: "unwanted",
        the_time: "its not my time"
    },
    start_action: function (tag, data, EditCallBack, isall) {
        Nominations.EditCallBack = EditCallBack;
        return new TemplateRenderer(data, tag, "~/Scripts/Components/Projects/Projects.html", null, false).start_action().
            then(jData => {
                Nominations.ShowDefaultTable();
                $("#datepicker").datepicker();
                $('#Start_Date').datepicker();
                const table = new DataTable('#your_nominations');
                Nominations.dt.on('click', 'tbody tr', (e) => {
                    let classList = e.currentTarget.classList;

                    if (classList.contains('selected')) {
                        classList.remove('selected');
                    }
                    else {
                        table.rows('.selected').nodes().each((row) => row.classList.remove('selected'));
                        classList.add('selected');
                    }
                });
            });
    },
    DeleteSelectedRow: function (e) {
        Nominations.dt.row('.selected').remove().draw(false);
    },
    AddNewRow: function (e) {
        Nominations.dt.row.add(['Aajay Ajmer', 'Architect Wastage', 'Ajanta & Ellora', '61', '2011-04-25', '$320,800']).draw(false);
    },
    EditSelectedRow: function (e) {
        //alert(Nominations.dt.row('.selected').data());
        //Nominations.dt.row('.selected').data(['Aajaa papa', 'Dumbo No.1', 'ALTSOM', '61', '2011-04-25', '$1320,800']).draw(false);
        let vals = Nominations.ids.map((val, i) => $("#" + val).val());
        let jsDate = $('#Start_Date').datepicker('getDate');
        jsDate instanceof Date; // -> true

        let day = jsDate.getDate();
        let formattedNumber = day.toLocaleString('en-US', {
            minimumIntegerDigits: 2,
            useGrouping: false
        })
        vals[vals.length - 2] = jsDate.getFullYear() + '-' + parseInt(jsDate.getMonth() + 1) + '-' + formattedNumber;
        Nominations.dt.row('.selected').data(vals);
        Nominations.myModal.hide(Nominations.myModal);
    },
    ShowModalEdit: function (e) {

        if (Nominations.dt.row('.selected').length <= 0) {
            Alertify.ShowAlertDialog({
                "title": "This is a serious matter",
                "body": "<h4 style=letter-spacing:3px;>Select the row you want to delete</h4>",
                "buttons": ["Ok Fine I got it", "Yes I want to delete"],
                "foot_note": "Edit from DataTables.NET"
            });
            return;
        }
        let element = document.getElementById('EditModal');
        let options = {}; options.focus = true; options.keyboard = true;
        Nominations.myModal = new bootstrap.Modal(element, options);
        Nominations.myModal.show(Nominations.myModal, 3000);
        let row_data = Nominations.dt.row('.selected').data();
        let ids = Nominations.ids;
        row_data.forEach((val, i) => $("#" + ids[i]).val(val));
    },

    EditCurrentRow: function (e, val) {
        let txt = $(e.target).attr("the_obj");
        let obj = JSON.parse(txt);
        obj.candidate_mail = obj.candidate_mail.substring(0, obj.candidate_mail.indexOf("span") - 1);
        obj.sponsor_mail = obj.sponsor_mail.substring(0, obj.sponsor_mail.indexOf("span") - 1);
        if (Nominations.EditCallBack) Nominations.EditCallBack(obj);
    },
    ShowDefaultTable: function () {
        let lengthMenu = [5, 10, 20, 50, 100, 200];
        let pageLength = lengthMenu[0];
        let hide_all = [1, 2, 3, 4, 5]
        Nominations.doTheDataTablesThing(lengthMenu, pageLength, hide_all);
        return "Your Nominations (0)";
    },
    doTheDataTablesThing: function (lengthMenu, pageLength, hide_all) {
        Nominations.dt =
            $('#your_nominations').DataTable({
                pageLength: pageLength,
                lengthMenu: lengthMenu,//[5, 10, 20, 50, 100, 200, 500], 
                dom: 'Bflrtip',
                buttons: [
                    {
                        extend: 'copyHtml5',
                        exportOptions: {
                            columns: [0, ':visible']
                        }
                    },
                    {
                        extend: 'excelHtml5',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },
                    {
                        extend: 'pdfHtml5',
                        exportOptions: {
                            columns: ':visible'
                            //columns: [0, 1, 2, 5]
                        }
                    },
                    {
                        extend: 'colvisGroup',
                        text: 'Show all',
                        show: ':hidden'
                    },
                    {
                        extend: 'colvisGroup',
                        text: 'Hide all',
                        hide: hide_all,
                        show: [1]
                    },
                    'colvis'
                ]
            });
        //var myTable = $('#your_nominations').DataTable();
        //$('#your_nominations').on('click', 'tbody tr', function () {
        //    myTable.row(this).edit({
        //        buttons: [
        //            { label: 'Cancel', fn: function () { this.close(); } },
        //            'Edit'
        //        ]
        //    });
        //});
    }
}
