﻿var Header = {
    myModal: null,
    TheIcon: null,
    log_off: `<div class="text-centered">
                 <button class="me-auto btn btn-outline-success border-4 rounded-circle " data-bs-toggle="modal" data-bs-target="#LogInModal">                
                    <i class="bi bi-cart4"></i>
                </button>
                <small class="d-block" id="welcome_message"></small>
              </div>`,
    log_in: '<a class="btn btn-outline-success" href="_VD_Home/Login#log_me_in" >Login</a>',
    start_action: function (jData, tag) {
        return (new TemplateRenderer(jData, tag, "~/Scripts/Components/Header/Header.html", null, false, true).start_action()).
            then(async (value) => {
                //$(".nav-link").on("click", (e) => TakeNavLinkAction($(e.target)));
                //$(document).on("click", ".nav-link", e => Header.TakeNavLinkAction($(e.target)));
                Header.ObserverURlChange();
                $("#welcome_message").html("");
                try {
                    //if (LoggedInUser.id <= 0) {
                        //$("#login_status").html(Header.log_in.replace(/_VD_/g, config.contextPath));
                      //  return "From header";
                    //}
                    let val = await $.ajax({ url: config.contextPath + "GetUserInfo" });
                    if (!val) return;
                    let jData = JSON.parse(val);
                    LoggedInUser.id = jData.id;
                    LoggedInUser.name = jData.name;
                    $("#acc_user_name").html(jData.name);
                    $("#acc_user_mail").html(jData.mail)
                    LoggedInUser.mail = jData.mail;
                    $("#acc_user_role").html(jData.roles);
                    LoggedInUser.roles = jData.roles;//.split(',');
                    if (!LoggedInUser.roles.find(x => x === 'admin')) $("#admin-link").hide();
                    $("#login_status").html(Header.log_off.replace(/_VD_/g, config.contextPath));//.replace(/_USER.IDENTITY.NAME_/g, jData.name));
                    if (jData.profileImagePath) $("#prof_img").attr({ "src": jData.profileImagePath });
                    $("#welcome_message").html("Welcome " + jData.name);
                } catch (xhr) {
                    alert("xhr : " + JSON.stringify(xhr, null, ' '));
                    $("#login_status").html(Header.log_in.replace(/_VD_/g, config.contextPath));
                    return "From header";
                }
            });
    },
    ObserverURlChange: function () {
        let previousUrl = '';
        const observer = new MutationObserver((mutationList, observer) => {
            if (location.href !== previousUrl) {
                previousUrl = location.href;
                // alert(`URL changed to `+ document.location.href);
                Header.HighlightNavigationMenu();
            }
        });
        const mutation_config = { subtree: true, childList: true };
        observer.observe(document, mutation_config);
    },
    TakeNavLinkAction: function (link) {
        $(".nav-link").removeClass("active");
        link.addClass("active");
    },
    HighlightNavigationMenu: function () {
        let url = window.location.pathname; // Returns path only (/path/example.html)
        let current_link = "a[class*='nav-link'][href='_URL_']".replace(/_URL_/, url);
        Header.TakeNavLinkAction($(current_link));
    },
    SetUserName: function (user_name) {
        Header.TheIcon.SetUserDetails();
    },
    handleFileSelect: async function (e) {
        Header.selectedFile = e.target.files[0];
        var fd = new FormData();
        fd.append("file", Header.selectedFile);
        let sumbit_ans_result = await $.ajax({
            url: config.contextPath + "SubmitProfileImage",
            type: "POST",
            method: "POST",
            //contentType: 'multipart/form-data',
            data: fd,
            contentType: false,
            processData: false,
        });        
        if (sumbit_ans_result) $("#prof_img").attr({ "src": sumbit_ans_result +"?"+ Math.random()*10000 });
    }
}
