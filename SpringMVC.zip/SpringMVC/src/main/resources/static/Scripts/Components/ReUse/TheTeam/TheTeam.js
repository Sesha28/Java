﻿var TheTeam = {
    start_action: function (tag, data) {
        new TemplateRenderer(data, tag, "~/Scripts/Components/ReUse/TheTeam/TheTeam.html", null, false).start_action();
    }
}