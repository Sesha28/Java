﻿var RefreshImage = {
    start_action: function (jData, tagOrJID) {
        new TemplateRenderer(jData, tagOrJID, "~/Scripts/Components/RefreshImage/RefreshImage.html").start_action().
        then(jD => {
				$("#img").attr("src" , "/showIMG?"+ Math.random()*100)
		})
    },
    refreshImage:function(e){
         	$("#img").attr("src","/showIMG?"+ Math.random()*100);
         }
}